<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\SavedFilter;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class FilterController extends Controller
{
    public function index(Request $request): JsonResponse
    {
        $filters = SavedFilter::where('user_id', $request->user()->id)
            ->orderBy('created_at', 'desc')
            ->get();

        return response()->json($filters);
    }

    public function store(Request $request): JsonResponse
    {
        $validated = $request->validate([
            'name' => 'required|string|max:255',
            'filters' => 'required|array',
        ]);

        $filter = SavedFilter::create([
            'user_id' => $request->user()->id,
            'name' => $validated['name'],
            'filters' => $validated['filters'],
        ]);

        return response()->json($filter, 201);
    }

    public function update(Request $request, $id): JsonResponse
    {
        $filter = SavedFilter::findOrFail($id);

        // Only owner can update
        if ($filter->user_id !== $request->user()->id) {
            return response()->json(['message' => 'Unauthorized'], 403);
        }

        $validated = $request->validate([
            'name' => 'sometimes|string|max:255',
            'filters' => 'sometimes|array',
        ]);

        $filter->update($validated);

        return response()->json($filter);
    }

    public function destroy(Request $request, $id): JsonResponse
    {
        $filter = SavedFilter::findOrFail($id);

        // Only owner can delete
        if ($filter->user_id !== $request->user()->id) {
            return response()->json(['message' => 'Unauthorized'], 403);
        }

        $filter->delete();

        return response()->json(['message' => 'Filter deleted successfully']);
    }
}
