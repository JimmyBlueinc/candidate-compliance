<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\ActivityLog;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class ActivityLogController extends Controller
{
    public function index(Request $request): JsonResponse
    {
        $user = $request->user();
        $filter = $request->input('filter', 'all');
        $search = $request->input('search', '');

        $query = ActivityLog::with('user')
            ->orderBy('created_at', 'desc')
            ->limit(100);

        // Filter by action
        if ($filter !== 'all') {
            $query->where('action', $filter);
        }

        // Search
        if ($search) {
            $query->where(function ($q) use ($search) {
                $q->where('entity_name', 'like', '%' . $search . '%')
                  ->orWhere('description', 'like', '%' . $search . '%');
            });
        }

        // Role-based filtering
        if ($user->role === 'candidate') {
            $query->where('user_id', $user->id);
        }

        $activities = $query->get()->map(function ($activity) {
            return [
                'id' => $activity->id,
                'user' => $activity->user->name ?? 'Unknown',
                'action' => $activity->action,
                'entity' => $activity->entity,
                'entity_name' => $activity->entity_name,
                'description' => $activity->description,
                'timestamp' => $activity->created_at->toIso8601String(),
            ];
        });

        return response()->json($activities);
    }
}
