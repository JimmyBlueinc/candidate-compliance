<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class PerformanceRecord extends Model
{
    use HasFactory;

    protected $fillable = [
        'user_id',
        'candidate_name',
        'record_type',
        'date',
        'rating',
        'reviewer_id',
        'notes',
        'document_path',
        'status',
    ];

    protected function casts(): array
    {
        return [
            'date' => 'date',
        ];
    }

    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class);
    }

    public function reviewer(): BelongsTo
    {
        return $this->belongsTo(User::class, 'reviewer_id');
    }

    protected $appends = ['document_url'];

    public function getDocumentUrlAttribute(): ?string
    {
        if (!$this->document_path) {
            return null;
        }
        
        $storageUrl = \Illuminate\Support\Facades\Storage::disk('public')->url($this->document_path);
        
        if (str_starts_with($storageUrl, 'http://') || str_starts_with($storageUrl, 'https://')) {
            return $storageUrl;
        }
        
        $baseUrl = null;
        try {
            if (app()->runningInConsole() === false && request()) {
                $baseUrl = request()->getSchemeAndHttpHost();
            }
        } catch (\Exception $e) {
            // Fall back to config
        }
        
        if (!$baseUrl) {
            $baseUrl = rtrim(config('app.url', 'http://localhost:8000'), '/');
        }
        
        $storagePath = $storageUrl;
        if (!str_starts_with($storagePath, '/')) {
            $storagePath = '/' . $storagePath;
        }
        
        return $baseUrl . $storagePath;
    }
}

